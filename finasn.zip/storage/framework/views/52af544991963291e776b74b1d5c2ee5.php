<?php # [BlazeVersion]:{v3} ?>
<div>
        <?php if (isset($component)) { $__componentOriginalfabd9bb39ad9685070e81a9acf61b581 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfabd9bb39ad9685070e81a9acf61b581 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.screen','data' => ['title' => 'Analisis']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('screen'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Analisis']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

         <?php $__env->slot('top', null, []); ?> 
            <?php if (isset($component)) { $__componentOriginal823597e28ef2afe3b8377997253f231c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal823597e28ef2afe3b8377997253f231c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.summary','data' => ['balance' => $balance,'income' => $income,'expense' => $expense]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('summary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['balance' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($balance),'income' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($income),'expense' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($expense)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal823597e28ef2afe3b8377997253f231c)): ?>
<?php $attributes = $__attributesOriginal823597e28ef2afe3b8377997253f231c; ?>
<?php unset($__attributesOriginal823597e28ef2afe3b8377997253f231c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal823597e28ef2afe3b8377997253f231c)): ?>
<?php $component = $__componentOriginal823597e28ef2afe3b8377997253f231c; ?>
<?php unset($__componentOriginal823597e28ef2afe3b8377997253f231c); ?>
<?php endif; ?>
         <?php $__env->endSlot(); ?>

        <div class="flex gap-1 rounded-[22px] bg-light p-1.5">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = ['daily' => 'Harian', 'weekly' => 'Mingguan', 'monthly' => 'Bulanan', 'yearly' => 'Tahunan']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <button wire:click="$set('period', '<?php echo e($key); ?>')"
                        class="h-[50px] flex-1 rounded-[19px] text-[15px] text-nav <?php echo e($period === $key ? 'bg-main font-medium' : ''); ?>"><?php echo e($label); ?></button>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>

        <div class="mt-5 rounded-[50px] bg-light px-7 py-6">
            <p class="text-[15px] font-medium text-ink">Pemasukan &amp; Pengeluaran</p>
            <div class="mt-5 flex h-[132px] items-end justify-between border-b border-dark px-2">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <div class="flex items-end gap-1.5">
                        <span class="w-1.5 rounded-t-full bg-main" style="height: <?php echo e(max(3, (int) round($r['income'] / $max * 132))); ?>px"></span>
                        <span class="w-1.5 rounded-t-full bg-ocean" style="height: <?php echo e(max(3, (int) round($r['expense'] / $max * 132))); ?>px"></span>
                    </div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </div>
            <div class="flex justify-between px-1 pt-1.5 font-spartan text-sm text-dark">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?> <span><?php echo e($r['label']); ?></span> <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </div>

            <div class="mt-5 grid grid-cols-2 text-center">
                <div>
                    <p class="text-[15px] font-medium text-ink"><span class="mr-1 inline-block size-2 rounded-full bg-main"></span>Pemasukan</p>
                    <p class="text-lg font-semibold text-ink"><?php echo e(\App\Support\Money::rp($totalIncome)); ?></p>
                </div>
                <div>
                    <p class="text-[15px] font-medium text-ink"><span class="mr-1 inline-block size-2 rounded-full bg-ocean"></span>Pengeluaran</p>
                    <p class="text-lg font-semibold text-ocean"><?php echo e(\App\Support\Money::rp($totalExpense)); ?></p>
                </div>
            </div>
        </div>

        <div class="mb-3 mt-6 flex items-center justify-between">
            <h2 class="text-[15px] font-medium text-ink">Budget Bulan Ini</h2>
            <button type="button" wire:click="createBudget" class="rounded-full bg-main px-4 py-2 text-xs font-medium text-ink">+ Tambah budget</button>
        </div>
        <div class="grid grid-cols-2 gap-4">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $targets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <?php $pct = $b->amount > 0 ? min(100, (int) round($b->spent() / $b->amount * 100)) : 0; ?>
                <div <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'budget-'.e($b->id).''; ?>wire:key="budget-<?php echo e($b->id); ?>" class="relative flex h-[190px] flex-col items-center justify-center gap-2 rounded-[36px] bg-sky px-2">
                    <div class="absolute right-3 top-3 flex gap-2 text-xs font-medium text-white">
                        <button type="button" wire:click="editBudget(<?php echo e($b->id); ?>)">Ubah</button>
                        <button type="button" wire:click="deleteBudget(<?php echo e($b->id); ?>)" wire:confirm="Hapus budget kategori ini?">Hapus</button>
                    </div>
                    <div class="grid size-[96px] place-items-center rounded-full" style="background: conic-gradient(#0068FF <?php echo e($pct); ?>%, #F1FFF3 0)">
                        <div class="grid size-[74px] place-items-center rounded-full bg-sky text-xl font-semibold text-mint"><?php echo e($pct); ?>%</div>
                    </div>
                    <p class="truncate text-[15px] font-medium text-mint"><?php echo e($b->category->name); ?></p>
                    <p class="text-center text-[10px] text-mint/90"><?php echo e(\App\Support\Money::rp($b->spent())); ?> / <?php echo e(\App\Support\Money::rp($b->amount)); ?></p>
                </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <p class="col-span-2 text-center text-sm text-nav/60">Belum ada budget bulan ini.</p>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfabd9bb39ad9685070e81a9acf61b581)): ?>
<?php $attributes = $__attributesOriginalfabd9bb39ad9685070e81a9acf61b581; ?>
<?php unset($__attributesOriginalfabd9bb39ad9685070e81a9acf61b581); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfabd9bb39ad9685070e81a9acf61b581)): ?>
<?php $component = $__componentOriginalfabd9bb39ad9685070e81a9acf61b581; ?>
<?php unset($__componentOriginalfabd9bb39ad9685070e81a9acf61b581); ?>
<?php endif; ?>

    <div x-data="{ open: <?php if ((object) ('budgetModal') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('budgetModal'->value()); ?>')<?php echo e('budgetModal'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('budgetModal'); ?>')<?php endif; ?> }" x-show="open" x-cloak class="fixed inset-0 z-40 grid place-items-center bg-black/50 px-6" x-on:keydown.escape.window="open = false">
        <form wire:submit="saveBudget" x-on:click.outside="open = false" class="w-full max-w-[339px] rounded-[20px] bg-white p-7">
            <h2 class="text-center text-xl font-bold text-dark"><?php echo e($budgetId ? 'Ubah Budget' : 'Budget Baru'); ?></h2>
            <label for="budget-category" class="label">Kategori pengeluaran</label>
            <select id="budget-category" name="category_id" autocomplete="off" wire:model="categoryId" class="field">
                <option value="">Pilih kategori</option>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $expenseCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </select>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['categoryId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1 text-xs text-red-500"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <label for="budget-amount" class="label">Batas budget (Rp)</label>
            <input id="budget-amount" name="amount" type="number" min="1" autocomplete="off" wire:model="budgetAmount" placeholder="Contoh: 1000000" class="field">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['budgetAmount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1 text-xs text-red-500"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <div class="mt-6 flex flex-col items-center gap-3"><button class="btn w-full max-w-[218px]">Simpan</button><button type="button" x-on:click="open = false" class="btn-soft w-full max-w-[218px]">Batal</button></div>
        </form>
    </div>
</div>
<?php /**PATH C:\Users\FIRMAN\OneDrive\Desktop\Folder Baru\finans\resources\views/livewire/analysis.blade.php ENDPATH**/ ?>