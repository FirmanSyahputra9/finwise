<?php # [BlazeVersion]:{v3} ?>
<div x-data="{ open: false }" x-on:saved.window="open = false">
    <?php if (isset($component)) { $__componentOriginalfabd9bb39ad9685070e81a9acf61b581 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfabd9bb39ad9685070e81a9acf61b581 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.screen','data' => ['title' => 'Categories']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('screen'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Categories']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

         <?php $__env->slot('top', null, []); ?> 
            <?php if (isset($component)) { $__componentOriginal823597e28ef2afe3b8377997253f231c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal823597e28ef2afe3b8377997253f231c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.summary','data' => ['balance' => $balance,'income' => $income,'expense' => $expense]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('summary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['balance' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($balance),'income' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($income),'expense' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($expense)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal823597e28ef2afe3b8377997253f231c)): ?>
<?php $attributes = $__attributesOriginal823597e28ef2afe3b8377997253f231c; ?>
<?php unset($__attributesOriginal823597e28ef2afe3b8377997253f231c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal823597e28ef2afe3b8377997253f231c)): ?>
<?php $component = $__componentOriginal823597e28ef2afe3b8377997253f231c; ?>
<?php unset($__componentOriginal823597e28ef2afe3b8377997253f231c); ?>
<?php endif; ?>
         <?php $__env->endSlot(); ?>

        <div class="grid grid-cols-3 gap-x-4 gap-y-6">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <div <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'c-'.e($c->id).''; ?>wire:key="c-<?php echo e($c->id); ?>" class="text-center">
                    <div class="grid h-[98px] place-items-center rounded-[26px] text-4xl font-semibold text-mint <?php echo e($loop->first ? 'bg-ocean' : 'bg-sky'); ?>">
                        <?php echo e(mb_strtoupper(mb_substr($c->name, 0, 1))); ?>

                    </div>
                    <p class="mt-2 truncate text-[15px] font-medium text-ink"><?php echo e($c->name); ?></p>
                </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

            <button x-on:click="open = true" class="text-center">
                <div class="grid h-[98px] place-items-center rounded-[26px] bg-sky text-mint"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'plus','class' => 'size-10']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'plus','class' => 'size-10']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></div>
                <p class="mt-2 text-[15px] font-medium text-ink">More</p>
            </button>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfabd9bb39ad9685070e81a9acf61b581)): ?>
<?php $attributes = $__attributesOriginalfabd9bb39ad9685070e81a9acf61b581; ?>
<?php unset($__attributesOriginalfabd9bb39ad9685070e81a9acf61b581); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfabd9bb39ad9685070e81a9acf61b581)): ?>
<?php $component = $__componentOriginalfabd9bb39ad9685070e81a9acf61b581; ?>
<?php unset($__componentOriginalfabd9bb39ad9685070e81a9acf61b581); ?>
<?php endif; ?>

    <div x-show="open" x-cloak class="fixed inset-0 z-40 grid place-items-center bg-black/50 px-6" x-on:keydown.escape.window="open = false">
        <form wire:submit="save" x-on:click.outside="open = false" class="w-full max-w-[339px] rounded-[20px] bg-white p-8">
            <h2 class="text-center text-xl font-bold text-dark">New Category</h2>
            <input id="category-name" name="name" type="text" autocomplete="off" wire:model="name" placeholder="Tulis nama kategori..." class="field mt-6">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1 text-xs text-red-500"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <div class="mt-6 flex flex-col items-center gap-3">
                <button type="submit" class="btn w-full max-w-[218px]">Save</button>
                <button type="button" x-on:click="open = false" class="btn-soft w-full max-w-[218px]">Cancel</button>
            </div>
        </form>
    </div>
</div>
<?php /**PATH C:\Users\FIRMAN\OneDrive\Desktop\Folder Baru\finans\resources\views\categories.blade.php ENDPATH**/ ?>