<?php # [BlazeVersion]:{v3} ?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="<?php echo e(asset('favicon.ico')); ?>" sizes="any">
    <link rel="icon" href="<?php echo e(asset('icons/finwise.svg')); ?>" type="image/svg+xml">
    <title>Masuk · finWise</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="min-h-dvh bg-mint font-poppins text-ink">
    <main class="mx-auto flex min-h-dvh max-w-md flex-col justify-center px-6 py-12">
        <p class="text-sm font-semibold uppercase tracking-[.2em] text-ocean">finWise</p>
        <h1 class="mt-3 text-3xl font-bold">Kelola uang dengan tenang.</h1>
        <p class="mt-2 text-sm text-nav/70">Masuk untuk melihat ringkasan keuanganmu.</p>
        <form method="post" action="<?php echo e(route('login.store')); ?>" class="mt-8 space-y-4 rounded-3xl bg-white p-6 shadow-sm">
            <?php echo csrf_field(); ?>
            <label class="block text-sm font-medium">Email<input class="field mt-2" type="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus autocomplete="email"></label>
            <label class="block text-sm font-medium">Kata sandi<input class="field mt-2" type="password" name="password" required autocomplete="current-password"></label>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-sm text-red-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <label class="flex items-center gap-2 text-sm"><input id="remember-me" type="checkbox" name="remember" value="1" autocomplete="off"> Ingat saya</label>
            <button class="btn w-full">Masuk</button>
        </form>
        <p class="mt-6 text-center text-sm">Belum punya akun? <a class="font-semibold text-ocean" href="<?php echo e(route('register')); ?>">Daftar</a></p>
    </main>
</body>
</html>
<?php /**PATH C:\Users\FIRMAN\OneDrive\Desktop\Folder Baru\finans\resources\views/auth/login.blade.php ENDPATH**/ ?>