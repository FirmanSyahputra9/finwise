<?php # [BlazeVersion]:{v3} ?>
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['t', 'odd' => true]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['t', 'odd' => true]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<div class="flex items-center gap-4 border-b border-light py-3">
    <div class="grid h-[53px] w-14 shrink-0 place-items-center rounded-[22px] text-xl font-semibold text-mint <?php echo e($odd ? 'bg-sky' : 'bg-blue'); ?>">
        <?php echo e(mb_strtoupper(mb_substr($t->category?->name ?? 'T', 0, 1))); ?>

    </div>
    <div class="min-w-0 flex-1">
        <p class="truncate text-[15px] font-medium text-nav"><?php echo e($t->category?->name ?? 'Transfer'); ?></p>
        <p class="text-xs font-semibold text-ocean"><?php echo e($t->date->translatedFormat('d M Y')); ?> · <?php echo e($t->account->name); ?></p>
    </div>
    <div class="text-right">
        <p class="text-[15px] font-medium <?php echo e($t->type->value === 'income' ? 'text-ink' : 'text-ocean'); ?>">
            <?php echo e($t->type->value === 'expense' ? '-' : ''); ?><?php echo e(\App\Support\Money::rp($t->amount)); ?>

        </p>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($t->note): ?>
            <p class="ml-auto max-w-24 truncate text-[13px] font-light text-nav"><?php echo e($t->note); ?></p>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
</div>
<?php /**PATH C:\Users\FIRMAN\OneDrive\Desktop\Folder Baru\finans\resources\views\components\transaction-row.blade.php ENDPATH**/ ?>