<?php # [BlazeVersion]:{v3} ?>
<?php ($rp = fn ($n) => 'Rp '.number_format($n, 0, ',', '.')); ?>
<div x-on:edit-transaction.window="document.getElementById('transaction-form')?.scrollIntoView({ behavior: 'smooth', block: 'start' })">
<?php if (isset($component)) { $__componentOriginalfabd9bb39ad9685070e81a9acf61b581 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfabd9bb39ad9685070e81a9acf61b581 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.screen','data' => ['title' => 'Transaksi']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('screen'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Transaksi']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <script type="application/json" id="offline-finance-data"><?php echo $offlineDataJson; ?></script>
    <form id="transaction-form" wire:submit="save" class="min-w-0 space-y-4 rounded-[24px] bg-white/70 p-4 sm:p-5">
        <input id="transaction-type" name="type" type="hidden" autocomplete="off" data-offline-field="type" value="<?php echo e($type); ?>">
        <h2 class="text-base font-semibold text-dark"><?php echo e($editingId ? 'Ubah transaksi' : 'Transaksi baru'); ?></h2>
        <div class="grid grid-cols-3 gap-1 rounded-[18px] bg-light p-1">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = ['expense' => 'Pengeluaran', 'income' => 'Pemasukan', 'transfer' => 'Transfer']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <button type="button" data-offline-type="<?php echo e($value); ?>" wire:click="$set('type', '<?php echo e($value); ?>')"
                    class="min-h-11 min-w-0 rounded-[14px] px-1 py-2 text-center text-[clamp(0.65rem,3.4vw,0.8rem)] font-medium leading-tight transition <?php echo e($type === $value ? 'bg-main text-ink shadow-sm' : 'bg-transparent text-dark/70'); ?>">
                    <span class="min-[380px]:hidden"><?php echo e(['expense' => 'Keluar', 'income' => 'Masuk', 'transfer' => 'Transfer'][$value]); ?></span>
                    <span class="hidden min-[380px]:inline"><?php echo e($label); ?></span>
                </button>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>

        <label for="transaction-amount" class="block text-xs font-medium text-dark/70">Nominal transaksi
            <span class="mt-1 flex min-w-0 items-center gap-3 rounded-[18px] bg-light px-4">
                <span class="shrink-0 text-base font-semibold text-dark/60">Rp</span>
                <input id="transaction-amount" name="amount" type="number" min="1" inputmode="numeric" autocomplete="off" data-offline-field="amount" wire:model="amount" placeholder="0" class="transaction-amount">
            </span>
        </label>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-xs text-red-500"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <select id="transaction-account" name="account_id" autocomplete="off" data-offline-field="account_id" wire:model="account_id" class="transaction-control">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?> <option value="<?php echo e($a->id); ?>"><?php echo e($a->name); ?></option> <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </select>
        <a href="<?php echo e(route('dashboard')); ?>" wire:navigate class="block text-right text-xs text-blue">Kelola akun</a>

        <div id="transaction-to-account-wrap" <?php if($type !== 'transfer'): ?> hidden <?php endif; ?>>
            <select id="transaction-to-account" name="to_account_id" autocomplete="off" data-offline-field="to_account_id" wire:model="to_account_id" class="transaction-control">
                <option value="">Ke akun...</option>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?> <option value="<?php echo e($a->id); ?>"><?php echo e($a->name); ?></option> <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </select>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['to_account_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-xs text-red-500"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
        <div id="transaction-category-wrap" <?php if($type === 'transfer'): ?> hidden <?php endif; ?>>
            <select id="transaction-category" name="category_id" autocomplete="off" data-offline-field="category_id" wire:model="category_id" class="transaction-control">
                <option value="">Kategori...</option>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $allCategories->filter(fn ($category) => $category->type->value === $type); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?> <option value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option> <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </select>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-xs text-red-500"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>

        <input id="transaction-date" name="date" type="date" autocomplete="off" data-offline-field="date" wire:model="date" class="transaction-control">
        <input id="transaction-note" name="note" type="text" autocomplete="off" data-offline-field="note" wire:model="note" placeholder="Catatan (opsional)" class="transaction-control">

        <button class="btn w-full"><?php echo e($editingId ? 'Simpan perubahan' : 'Simpan transaksi'); ?></button>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($editingId): ?>
            <button type="button" wire:click="cancelEdit" class="btn-soft w-full">Batal mengubah</button>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </form>

    <div class="flex flex-wrap items-center justify-between gap-2">
        <h2 class="font-semibold">Riwayat</h2>
        <select id="transaction-filter-type" name="filter_type" autocomplete="off" wire:model.live="filterType" class="transaction-control w-auto text-sm">
            <option value="">Semua</option>
            <option value="income">Pemasukan</option>
            <option value="expense">Pengeluaran</option>
            <option value="transfer">Transfer</option>
        </select>
    </div>

    <div class="grid min-w-0 grid-cols-1 gap-2 rounded-2xl bg-white/70 p-3 min-[380px]:grid-cols-2">
        <input id="transaction-search" name="search" type="search" autocomplete="off" wire:model.live.debounce.300ms="search" placeholder="Cari catatan, kategori, akun..." class="field min-[380px]:col-span-2">
        <select id="transaction-filter-account" name="filter_account" autocomplete="off" wire:model.live="filterAccount" class="transaction-control text-sm"><option value="">Semua akun</option><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?><option value="<?php echo e($a->id); ?>"><?php echo e($a->name); ?></option><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?></select>
        <select id="transaction-filter-category" name="filter_category" autocomplete="off" wire:model.live="filterCategory" class="transaction-control text-sm"><option value="">Semua kategori</option><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $allCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?><option value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?></select>
        <label for="transaction-date-from" class="text-xs text-dark/70">Dari<input id="transaction-date-from" name="date_from" type="date" autocomplete="off" wire:model.live="dateFrom" class="transaction-control mt-1 text-sm"></label>
        <label for="transaction-date-to" class="text-xs text-dark/70">Sampai<input id="transaction-date-to" name="date_to" type="date" autocomplete="off" wire:model.live="dateTo" class="transaction-control mt-1 text-sm"></label>
        <button type="button" wire:click="resetFilters" class="col-span-2 text-right text-xs text-blue">Reset filter</button>
    </div>

    <ul class="divide-y divide-dark/10 rounded-2xl bg-white/70">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <li class="grid min-w-0 grid-cols-[minmax(0,1fr)_auto] items-center gap-2 p-3 text-sm" <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 't-'.e($t->id).''; ?>wire:key="t-<?php echo e($t->id); ?>">
                <div class="min-w-0">
                    <p class="font-medium"><?php echo e($t->category?->name ?? ($t->type->value === 'transfer' ? 'Transfer ke '.$t->toAccount?->name : $t->type->label())); ?></p>
                    <p class="text-gray-500"><?php echo e($t->date->translatedFormat('d M Y')); ?> · <?php echo e($t->account->name); ?><?php echo e($t->note ? ' · '.$t->note : ''); ?></p>
                </div>
                <div class="flex min-w-0 flex-col items-end gap-1">
                    <span class="whitespace-nowrap text-xs font-semibold tabular-nums sm:text-sm <?php echo e($t->type->value === 'income' ? 'text-emerald-600' : 'text-red-500'); ?>">
                        <?php echo e($t->type->value === 'income' ? '+' : '-'); ?><?php echo e($rp($t->amount)); ?>

                    </span>
                    <div class="flex shrink-0 gap-3">
                        <button type="button" wire:click="edit(<?php echo e($t->id); ?>)" class="text-xs text-blue">Ubah</button>
                        <button type="button" wire:click="delete(<?php echo e($t->id); ?>)" wire:confirm="Hapus transaksi ini?" class="text-xs text-red-600">Hapus</button>
                    </div>
                </div>
            </li>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            <li class="p-3 text-sm text-gray-500">Belum ada transaksi.</li>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </ul>

    <?php echo e($transactions->links()); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfabd9bb39ad9685070e81a9acf61b581)): ?>
<?php $attributes = $__attributesOriginalfabd9bb39ad9685070e81a9acf61b581; ?>
<?php unset($__attributesOriginalfabd9bb39ad9685070e81a9acf61b581); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfabd9bb39ad9685070e81a9acf61b581)): ?>
<?php $component = $__componentOriginalfabd9bb39ad9685070e81a9acf61b581; ?>
<?php unset($__componentOriginalfabd9bb39ad9685070e81a9acf61b581); ?>
<?php endif; ?>
</div>
<?php /**PATH C:\Users\FIRMAN\OneDrive\Desktop\Folder Baru\finans\resources\views\livewire\transactions\index.blade.php ENDPATH**/ ?>