<?php # [BlazeVersion]:{v3} ?>
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['balance', 'expense', 'income']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['balance', 'expense', 'income']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php
    $pct = $income > 0 ? min(100, (int) round($expense / $income * 100)) : 0;
?>
<div class="mt-7">
    <div class="grid grid-cols-2 text-center">
        <div class="border-r border-light">
            <p class="text-xs text-ink">Total Balance</p>
            <p class="text-2xl font-bold text-mint"><?php echo e(\App\Support\Money::rp($balance)); ?></p>
        </div>
        <div>
            <p class="text-xs text-ink">Total Expense</p>
            <p class="text-2xl font-semibold text-ocean">-<?php echo e(\App\Support\Money::rp($expense)); ?></p>
        </div>
    </div>

    <div class="relative mt-5 h-[27px] overflow-hidden rounded-full bg-mint">
        <div class="absolute inset-y-0 left-0 flex items-center rounded-full bg-nav px-3 text-xs text-mint"
             style="width: max(14%, <?php echo e($pct); ?>%)"><?php echo e($pct); ?>%</div>
        <span class="absolute right-3 top-1/2 -translate-y-1/2 text-[13px] font-medium italic text-nav"><?php echo e(\App\Support\Money::rp($income)); ?></span>
    </div>
    <p class="mt-3 text-center text-[15px] text-nav"><?php echo e($pct); ?>% of your expenses, <?php echo e($pct <= 50 ? 'looks good.' : 'be careful!'); ?></p>
</div>
<?php /**PATH C:\Users\FIRMAN\OneDrive\Desktop\Folder Baru\finans\resources\views\components\summary.blade.php ENDPATH**/ ?>