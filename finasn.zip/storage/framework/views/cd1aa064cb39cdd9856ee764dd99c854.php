<?php # [BlazeVersion]:{v3} ?>
<?php

use Livewire\Component;

new class extends Component
{
    //
};
?>

<div>
    
</div><?php /**PATH C:\Users\FIRMAN\OneDrive\Desktop\Folder Baru\finans\resources\views\components\⚡dashboard.blade.php ENDPATH**/ ?>