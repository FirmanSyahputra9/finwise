<?php # [BlazeVersion]:{v3} ?>


<?php $__env->startSection('title', __('Service Unavailable')); ?>
<?php $__env->startSection('code', '503'); ?>
<?php $__env->startSection('message', __('Service Unavailable')); ?>

<?php echo $__env->make('errors::minimal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\FIRMAN\OneDrive\Desktop\Folder Baru\finans\vendor\laravel\framework\src\Illuminate\Foundation\Exceptions\views\503.blade.php ENDPATH**/ ?>