<?php # [BlazeVersion]:{v3} ?>
<div x-data="{ open: false }">
    <?php if (isset($component)) { $__componentOriginalfabd9bb39ad9685070e81a9acf61b581 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfabd9bb39ad9685070e81a9acf61b581 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.screen','data' => ['title' => 'Profile']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('screen'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Profile']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

         <?php $__env->slot('top', null, []); ?> 
            <div class="mt-6 flex justify-center">
                <div class="grid size-[117px] place-items-center rounded-full bg-sky text-5xl font-semibold text-mint ring-4 ring-light">
                    <?php echo e(mb_strtoupper(mb_substr($user->name, 0, 1))); ?>

                </div>
            </div>
         <?php $__env->endSlot(); ?>

        <div class="text-center">
            <p class="text-xl font-bold capitalize text-dark"><?php echo e($user->name); ?></p>
            <p class="text-[13px] font-semibold text-ink">ID: <?php echo e(str_pad((string) $user->id, 8, '0', STR_PAD_LEFT)); ?></p>
        </div>

        <div class="mt-8 space-y-8">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = [['edit', 'Edit Profile', 'bg-sky'], ['security', 'Security', 'bg-blue'], ['setting', 'Setting', 'bg-ocean'], ['help', 'Help', 'bg-sky']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$icon, $label, $color]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <a href="#" class="flex items-center gap-4">
                    <span class="grid h-[53px] w-14 place-items-center rounded-[22px] text-mint <?php echo e($color); ?>"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => $icon,'class' => 'size-6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($icon),'class' => 'size-6']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></span>
                    <span class="text-[15px] font-medium text-ink"><?php echo e($label); ?></span>
                </a>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

            <button x-on:click="open = true" class="flex items-center gap-4">
                <span class="grid h-[53px] w-14 place-items-center rounded-[22px] bg-blue text-mint"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'logout','class' => 'size-6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'logout','class' => 'size-6']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></span>
                <span class="text-[15px] font-medium text-ink">Logout</span>
            </button>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfabd9bb39ad9685070e81a9acf61b581)): ?>
<?php $attributes = $__attributesOriginalfabd9bb39ad9685070e81a9acf61b581; ?>
<?php unset($__attributesOriginalfabd9bb39ad9685070e81a9acf61b581); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfabd9bb39ad9685070e81a9acf61b581)): ?>
<?php $component = $__componentOriginalfabd9bb39ad9685070e81a9acf61b581; ?>
<?php unset($__componentOriginalfabd9bb39ad9685070e81a9acf61b581); ?>
<?php endif; ?>

    <div x-show="open" x-cloak class="fixed inset-0 z-40 grid place-items-center bg-black/50 px-6" x-on:keydown.escape.window="open = false">
        <div x-on:click.outside="open = false" class="w-full max-w-[339px] rounded-[20px] bg-white px-8 py-10 text-center">
            <h2 class="text-xl font-bold capitalize text-dark">End Session</h2>
            <p class="mt-3 font-spartan text-[17px] text-[#363130]">Are you sure you want to log out?</p>
            <div class="mt-8 flex flex-col items-center gap-3">
                <button wire:click="logout" class="btn w-full max-w-[218px]">Yes, End Session</button>
                <button x-on:click="open = false" class="btn-soft w-full max-w-[218px]">Cancel</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\FIRMAN\OneDrive\Desktop\Folder Baru\finans\resources\views\profile.blade.php ENDPATH**/ ?>