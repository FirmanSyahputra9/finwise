<?php # [BlazeVersion]:{v3} ?>
<?php ($rp = fn ($n) => 'Rp '.number_format($n, 0, ',', '.')); ?>
<div x-data>
    <?php if (isset($component)) { $__componentOriginalfabd9bb39ad9685070e81a9acf61b581 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfabd9bb39ad9685070e81a9acf61b581 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.screen','data' => ['title' => 'Target Simpanan']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('screen'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Target Simpanan']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

         <?php $__env->slot('top', null, []); ?> 
            <?php if (isset($component)) { $__componentOriginal823597e28ef2afe3b8377997253f231c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal823597e28ef2afe3b8377997253f231c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.summary','data' => ['balance' => $balance,'income' => $income,'expense' => $expense]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('summary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['balance' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($balance),'income' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($income),'expense' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($expense)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal823597e28ef2afe3b8377997253f231c)): ?>
<?php $attributes = $__attributesOriginal823597e28ef2afe3b8377997253f231c; ?>
<?php unset($__attributesOriginal823597e28ef2afe3b8377997253f231c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal823597e28ef2afe3b8377997253f231c)): ?>
<?php $component = $__componentOriginal823597e28ef2afe3b8377997253f231c; ?>
<?php unset($__componentOriginal823597e28ef2afe3b8377997253f231c); ?>
<?php endif; ?>
         <?php $__env->endSlot(); ?>

        <div class="mb-5 flex items-center justify-between">
            <div><h2 class="text-lg font-semibold text-ink">Impianmu, satu per satu</h2><p class="text-xs text-dark/60">Catat progres tabunganmu di sini.</p></div>
            <button type="button" wire:click="create" class="grid size-11 place-items-center rounded-full bg-dark text-mint" aria-label="Buat target"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'plus','class' => 'size-6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'plus','class' => 'size-6']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></button>
        </div>

        <div class="space-y-4">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $goals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $goal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <?php ($pct = $goal->target_amount > 0 ? min(100, (int) floor($goal->saved_amount / $goal->target_amount * 100)) : 0); ?>
                <article <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'goal-'.e($goal->id).''; ?>wire:key="goal-<?php echo e($goal->id); ?>" class="rounded-[22px] bg-white p-4 shadow-sm">
                    <div class="flex items-start justify-between gap-3">
                        <div class="min-w-0"><h3 class="truncate font-semibold text-ink"><?php echo e($goal->name); ?></h3>
                            <p class="mt-1 text-xs text-dark/60"><?php echo e($goal->target_date ? 'Target '.$goal->target_date->translatedFormat('d M Y') : 'Tanpa batas waktu'); ?></p></div>
                        <div class="flex shrink-0 gap-2">
                            <button type="button" wire:click="edit(<?php echo e($goal->id); ?>)" class="rounded-full bg-light px-3 py-1 text-xs text-dark">Ubah</button>
                            <button type="button" wire:click="delete(<?php echo e($goal->id); ?>)" wire:confirm="Hapus target <?php echo e($goal->name); ?>?" class="rounded-full bg-red-50 px-3 py-1 text-xs text-red-600">Hapus</button>
                        </div>
                    </div>
                    <div class="mt-4 flex items-end justify-between"><p class="text-lg font-bold text-dark"><?php echo e($rp($goal->saved_amount)); ?></p><p class="text-xs text-dark/60">dari <?php echo e($rp($goal->target_amount)); ?></p></div>
                    <div class="mt-2 h-2.5 overflow-hidden rounded-full bg-light"><div class="h-full rounded-full bg-main transition-all" style="width: <?php echo e($pct); ?>%"></div></div>
                    <div class="mt-1 flex justify-between text-[11px] text-dark/60"><span><?php echo e($pct); ?>% terkumpul</span><span><?php echo e($goal->saved_amount >= $goal->target_amount ? 'Tercapai! 🎉' : 'Kurang '.$rp($goal->target_amount - $goal->saved_amount)); ?></span></div>
                    <form wire:submit="addContribution(<?php echo e($goal->id); ?>)" class="mt-4 flex gap-2">
                        <input type="number" min="1" step="1" wire:model="contribution" placeholder="Nominal tabungan" class="field flex-1" aria-label="Nominal tabungan">
                        <button type="submit" class="rounded-full bg-dark px-4 text-xs font-medium text-mint">Tambah</button>
                    </form>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['contribution'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1 text-xs text-red-500"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </article>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <div class="rounded-[22px] bg-white/70 px-5 py-10 text-center"><p class="text-4xl">🐷</p><p class="mt-3 font-semibold text-ink">Belum ada target simpanan</p><p class="mt-1 text-sm text-dark/60">Mulai dari hal yang kamu impikan.</p><button type="button" wire:click="create" class="btn mt-5">Buat target pertama</button></div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfabd9bb39ad9685070e81a9acf61b581)): ?>
<?php $attributes = $__attributesOriginalfabd9bb39ad9685070e81a9acf61b581; ?>
<?php unset($__attributesOriginalfabd9bb39ad9685070e81a9acf61b581); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfabd9bb39ad9685070e81a9acf61b581)): ?>
<?php $component = $__componentOriginalfabd9bb39ad9685070e81a9acf61b581; ?>
<?php unset($__componentOriginalfabd9bb39ad9685070e81a9acf61b581); ?>
<?php endif; ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($formOpen): ?>
        <div class="fixed inset-0 z-40 grid place-items-center bg-black/50 px-6" wire:click.self="$set('formOpen', false)" x-on:keydown.escape.window="$wire.set('formOpen', false)">
            <form wire:submit="save" class="w-full max-w-[360px] rounded-[24px] bg-white p-6">
                <h2 class="text-center text-xl font-bold text-dark"><?php echo e($editingId ? 'Ubah target' : 'Target baru'); ?></h2>
                <label class="label" for="goal-name">Nama target</label><input id="goal-name" type="text" wire:model="name" placeholder="Contoh: Dana liburan" class="field">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1 text-xs text-red-500"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <label class="label" for="goal-amount">Jumlah yang ingin dikumpulkan</label><input id="goal-amount" type="number" min="1" step="1" wire:model="targetAmount" placeholder="5000000" class="field">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['targetAmount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1 text-xs text-red-500"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <label class="label" for="goal-date">Batas waktu <span class="font-normal text-dark/50">(opsional)</span></label><input id="goal-date" type="date" wire:model="targetDate" class="field">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['targetDate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1 text-xs text-red-500"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <button type="submit" class="btn mt-6 w-full">Simpan target</button>
                <button type="button" wire:click="$set('formOpen', false)" class="btn-soft mt-2 w-full">Batal</button>
            </form>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>
<?php /**PATH C:\Users\FIRMAN\OneDrive\Desktop\Folder Baru\finans\resources\views/livewire/savings-goals.blade.php ENDPATH**/ ?>