<?php # [BlazeVersion]:{v3} ?>
<?php ($rp = fn ($n) => 'Rp '.number_format($n, 0, ',', '.')); ?>
<?php if (isset($component)) { $__componentOriginalfabd9bb39ad9685070e81a9acf61b581 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfabd9bb39ad9685070e81a9acf61b581 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.screen','data' => ['title' => 'Beranda']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('screen'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Beranda']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <script type="application/json" id="offline-finance-data"><?php echo $offlineDataJson; ?></script>
     <?php $__env->slot('top', null, []); ?> 
        <div class="mt-5 rounded-[26px] bg-dark p-5 text-mint">
        <p class="text-sm opacity-80">Total Saldo</p>
        <p class="text-3xl font-bold"><?php echo e($rp($totalBalance)); ?></p>
        <div class="mt-4 grid grid-cols-2 gap-4 text-sm">
            <div><p class="opacity-80">Pemasukan</p><p class="font-semibold"><?php echo e($rp($income)); ?></p></div>
            <div><p class="opacity-80">Pengeluaran</p><p class="font-semibold"><?php echo e($rp($expense)); ?></p></div>
        </div>
        </div>
     <?php $__env->endSlot(); ?>

<div class="space-y-6">

    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('account-manager', []);

$__keyOuter = $__key ?? null;

$__key = null;
$__componentSlots = [];

$__key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-263882801-0', $__key);

$__html = app('livewire')->mount($__name, $__params, $__key, $__componentSlots);

echo $__html;

unset($__html);
unset($__key);
$__key = $__keyOuter;
unset($__keyOuter);
unset($__name);
unset($__params);
unset($__componentSlots);
unset($__split);
?>

    <section>
        <h2 class="mb-2 font-semibold">Budget bulan ini</h2>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $budgets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $budget): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <?php ($spent = $budget->spent()); ?>
            <?php ($pct = $budget->amount > 0 ? min(100, round($spent / $budget->amount * 100)) : 0); ?>
            <div class="mb-3">
                <div class="flex justify-between text-sm">
                    <span><?php echo e($budget->category->name); ?></span>
                    <span><?php echo e($rp($spent)); ?> / <?php echo e($rp($budget->amount)); ?></span>
                </div>
                <div class="h-2 rounded bg-gray-200">
                    <div class="h-2 rounded <?php echo e($pct >= 100 ? 'bg-red-500' : 'bg-emerald-500'); ?>" style="width: <?php echo e($pct); ?>%"></div>
                </div>
            </div>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            <p class="text-sm text-nav/60">Belum ada budget.</p>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </section>

    <section>
        <div class="mb-2 flex justify-between">
            <h2 class="font-semibold">Transaksi terakhir</h2>
            <a href="<?php echo e(route('transactions')); ?>" wire:navigate class="text-sm text-emerald-600">Lihat semua</a>
        </div>
        <ul class="divide-y divide-dark/10 rounded-2xl bg-white/70">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $recent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <li class="flex justify-between p-3 text-sm">
                    <div>
                        <p class="font-medium"><?php echo e($t->category?->name ?? $t->type->label()); ?></p>
                        <p class="text-gray-500"><?php echo e($t->date->translatedFormat('d M Y')); ?> · <?php echo e($t->account->name); ?></p>
                    </div>
                    <p class="<?php echo e($t->type->value === 'income' ? 'text-emerald-600' : 'text-red-500'); ?>">
                        <?php echo e($t->type->value === 'income' ? '+' : '-'); ?><?php echo e($rp($t->amount)); ?>

                    </p>
                </li>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <li class="p-3 text-sm text-gray-500">Belum ada transaksi.</li>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </ul>
        <a href="<?php echo e(route('transactions')); ?>" wire:navigate class="btn mt-4 flex items-center justify-center">Tambah transaksi</a>
    </section>
</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfabd9bb39ad9685070e81a9acf61b581)): ?>
<?php $attributes = $__attributesOriginalfabd9bb39ad9685070e81a9acf61b581; ?>
<?php unset($__attributesOriginalfabd9bb39ad9685070e81a9acf61b581); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfabd9bb39ad9685070e81a9acf61b581)): ?>
<?php $component = $__componentOriginalfabd9bb39ad9685070e81a9acf61b581; ?>
<?php unset($__componentOriginalfabd9bb39ad9685070e81a9acf61b581); ?>
<?php endif; ?>
<?php /**PATH C:\Users\FIRMAN\OneDrive\Desktop\Folder Baru\finans\resources\views\livewire\dashboard.blade.php ENDPATH**/ ?>